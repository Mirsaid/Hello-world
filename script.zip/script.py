name = input("Enter name:")
print("Hello " + name)
